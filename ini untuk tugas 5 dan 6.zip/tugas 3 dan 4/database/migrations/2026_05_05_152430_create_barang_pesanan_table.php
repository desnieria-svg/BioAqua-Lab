<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('barang_pesanan', function (Blueprint $table) {
            $table->id();
            $table->foreignId('barang_id')->constrained('barangs')->onDelete('cascade');
            $table->foreignId('pesanan_id')->constrained('pesanans')->onDelete('cascade');
            $table->integer('jumlah'); // Kolom tambahan untuk tahu jumlah barang yang dipesan
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('barang_pesanan');
    }
};

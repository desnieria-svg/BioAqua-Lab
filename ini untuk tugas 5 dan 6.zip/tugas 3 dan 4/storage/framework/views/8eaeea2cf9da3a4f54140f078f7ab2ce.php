<?php $__env->startSection('title', 'Kontak Kami'); ?>

<?php $__env->startSection('content'); ?>

<div class="dashboard-wrapper">

    <div class="tentang-card">

        <h1>📞 Kontak BioAqua Lab</h1>

        <p>Ada pertanyaan atau ingin memesan? Hubungi kami melalui:</p>

        <ul>
            <li>📍 Jl. Tirta Murni No. 24, Bandung, Jawa Barat</li>
            <li>📞 +62 22 123-456</li>
            <li>📱 +62 812-3456-7890 (WhatsApp)</li>
            <li>✉️ info@bioaqua.lab</li>
            <li>🕐 Senin–Sabtu: 07.00 – 18.00 WIB</li>
        </ul>

        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">← Kembali ke Home</a>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        console.log('Halaman Kontak loaded!');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BioAquaLab\resources\views/pages/kontak.blade.php ENDPATH**/ ?>
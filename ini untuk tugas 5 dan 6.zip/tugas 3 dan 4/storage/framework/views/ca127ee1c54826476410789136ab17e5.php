<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="dashboard-wrapper">

    
    <div class="dashboard-header">
        <h1>📊 Dashboard BioAqua Lab</h1>
        <p>Selamat datang! Berikut ringkasan data dari database hari ini.</p>
    </div>

    
    <div class="stat-grid">
        <?php $__empty_1 = true; $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if (isset($component)) { $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stat-card','data' => ['judul' => $stat['judul'],'nilai' => $stat['nilai'],'ikon' => $stat['ikon'],'warna' => $stat['warna']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('stat-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['judul' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['judul']),'nilai' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['nilai']),'ikon' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['ikon']),'warna' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($stat['warna'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $attributes = $__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__attributesOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682)): ?>
<?php $component = $__componentOriginal527fae77f4db36afc8c8b7e9f5f81682; ?>
<?php unset($__componentOriginal527fae77f4db36afc8c8b7e9f5f81682); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Tidak ada data statistik.</p>
        <?php endif; ?>
    </div>

    
    <div class="dashboard-table">
        <h2>📋 Daftar Pesanan Terbaru (Data Asli)</h2>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Pelanggan</th>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Total Harga</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $barangTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        
                        <td style="font-weight: 600;"><?php echo e($pesanan->nama_pelanggan); ?></td>
                        <td><?php echo e($pesanan->nama_produk); ?></td>
                        <td><?php echo e($pesanan->jumlah); ?></td>
                        <td style="font-weight: bold; color: #2563eb;">
                            Rp <?php echo e(number_format($pesanan->total_harga, 0, ',', '.')); ?>

                        </td>
                        <td>
                            <span class="status <?php echo e($pesanan->status); ?>">
                                <?php echo e(strtoupper($pesanan->status)); ?>

                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="text-align: center;">Belum ada data pesanan di database.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        console.log('Dashboard BioAqua Lab loaded with real data!');
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\BioAquaLab\resources\views/dashboard.blade.php ENDPATH**/ ?>
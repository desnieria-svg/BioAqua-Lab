<header class="navbar" id="navbar">
  <div class="nav-inner">

    <a href="/" class="nav-logo">
      <img src="<?php echo e(asset('images/logo.png')); ?>" class="logo-img">
      <span>BioAqua Lab</span>
    </a>

    <nav class="nav-menu">
      <a href="/" class="nav-link">Home</a>
      <a href="#produk" class="nav-link">Produk</a>
      <a href="#pesanan" class="nav-link">Pesanan</a>
      <a href="/kontak" class="nav-link">Kontak</a>

      <!-- INI YANG WAJIB ADA -->
      <a href="/tentang" class="nav-link">Tentang</a>
    </nav>

  </div>
</header>
<?php /**PATH C:\xampp\htdocs\BioAquaLab\resources\views/components/navbar.blade.php ENDPATH**/ ?>
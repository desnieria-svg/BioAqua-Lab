<footer class="footer">
  <p>© BioAqua Lab</p>
</footer>
<?php /**PATH C:\xampp\htdocs\BioAquaLab\resources\views/components/footer.blade.php ENDPATH**/ ?>